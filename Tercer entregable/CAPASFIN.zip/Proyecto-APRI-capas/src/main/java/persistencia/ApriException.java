
package persistencia;

public class ApriException extends Exception {
    
    public ApriException(String message){
        super(message);
    }
    
}
