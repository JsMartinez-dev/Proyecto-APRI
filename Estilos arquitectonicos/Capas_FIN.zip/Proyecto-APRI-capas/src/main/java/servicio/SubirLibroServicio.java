
package servicio;

import java.io.InputStream;
import java.util.logging.Level;
import java.util.logging.Logger;
import modelo.Libro;
import modelo.Usuario;
import persistencia.ApriException;
import persistencia.DaoLibro;
import persistencia.DaoLibroImp;


public class SubirLibroServicio {
    
    DaoLibro daoLibro;
    
    public SubirLibroServicio(){
        daoLibro = new DaoLibroImp();
    }
 
    public boolean subirLibro(Libro librito, Usuario user, InputStream inputStream) throws Exception {
    
    if(librito != null && user != null && inputStream != null){
        if(librito.isEstado()){
                try {
                    return daoLibro.registrar(librito, user, inputStream);
                } catch (Exception ex) {
                    System.err.println("Error en DAO: " + ex.getMessage());
                    ex.printStackTrace();
                    throw new ApriException("Fallo el uso del DAOLIBRO: " + ex.getMessage());
                }
            
        } else {
            System.out.println("FALLO: Libro no tiene estado activo");
        }
    } else {
        System.out.println("FALLO: Algún parámetro es null");
    }
    return false;
    }
    /* DEBUGGING con logs para ver porque no registraba (IMPORTANTE!!)
public boolean subirMaterial(Libro librito, Usuario user, InputStream inputStream) throws Exception {
    System.out.println("=== INICIO subirMaterial ===");
    System.out.println("Libro es null? " + (librito == null));
    System.out.println("Usuario es null? " + (user == null));
    System.out.println("InputStream es null? " + (inputStream == null));
    
    if(librito != null && user != null && inputStream != null){
        System.out.println("Libro estado: " + librito.isEstado());
        System.out.println("Usuario estado: " + user.isEstado());
        
        if(librito.isEstado()){
            System.out.println("PASO VALIDACION LIBRO");
                System.out.println("PASO VALIDACION USUARIO - Llamando al DAO");
                try {
                    return daoLibro.registrar(librito, user, inputStream);
                } catch (Exception ex) {
                    System.err.println("Error en DAO: " + ex.getMessage());
                    ex.printStackTrace();
                    throw new ApriException("Fallo el uso del DAOLIBRO: " + ex.getMessage());
                }
            
        } else {
            System.out.println("FALLO: Libro no tiene estado activo");
        }
    } else {
        System.out.println("FALLO: Algún parámetro es null");
    }
    return false;
}
    */
    
}
