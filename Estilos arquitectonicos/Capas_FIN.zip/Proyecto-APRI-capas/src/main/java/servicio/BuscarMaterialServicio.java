
package servicio;

import java.util.List;
import modelo.MaterialEducativo;
import modelo.Usuario;
import persistencia.DaoLibro;
import persistencia.DaoLibroImp;



public class BuscarMaterialServicio {
    
    DaoLibro daoLib;
    
    
    public BuscarMaterialServicio(){
        daoLib = new DaoLibroImp();
    }
    
    
    public List<MaterialEducativo> buscarMaterial(Usuario usuario){
        
        if(usuario!=null){
            try {
                return daoLib.buscarListUser(usuario);
            } catch (Exception ex) {
                System.out.println("Erro en la capa de servicio libro, Error: "+ex.getMessage());
            }
           
        }
       return null;  
    }
}
