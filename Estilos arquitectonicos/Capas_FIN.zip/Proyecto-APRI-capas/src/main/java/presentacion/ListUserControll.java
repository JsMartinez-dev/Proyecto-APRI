/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package presentacion;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import modelo.Usuario;
import servicio.ListUserServicio;

/**
 *
 * @author ACER-A315-59
 */
@WebServlet(name = "ListUserControll", urlPatterns = {"/ListUserControll"})
public class ListUserControll extends HttpServlet {
    
    
    ListUserServicio listUServicio;

   @Override
    public void init(){
        listUServicio = new ListUserServicio();
    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        try {
            List<Usuario> listaU = listUServicio.listUser();
            System.out.println("PASO LA dOGET");
            
            if(listaU !=null){
                
                String vista = request.getParameter("vista");
                String destino = "";
                
                if(vista.equals("dashboardN")){
                    destino = "DashboardAdmin.jsp";
                }else if( vista.equals("dashboardGU")){
                    destino = "DashboardAdmin_GU.jsp";
                }
                request.setAttribute("listU",listaU);
                request.getRequestDispatcher(destino).forward(request, response);
            }else{
                response.getWriter().print("ERROR EN EL GESTION USUARIOS");
            }
        } catch (Exception ex) {
            System.out.println("ERROR EN EL DoGett, Error: "+ex.getMessage());
        }
        
    }


    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
